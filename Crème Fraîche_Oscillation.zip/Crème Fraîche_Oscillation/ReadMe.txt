Tipo de Jogo: Platform

Na mitologia grega Chárōn o barqueiro de Hades carrega as almas dos recém-mortos sobre as águas do rio Estige, 
este que dividia o mundo dos vivos do mundo dos mortos. 
Para efectuar esta travessia o jogador terá de coletar moedas durante a sua viagem de forma a pagar a Chárōn 
para alimentar a chama de luz que guia o seu caminho. Ao longo do tempo esta vai se desvanecendo e tem de ser 
alimentada regularmente caso contrário a escuridão emergirá.

Controlos:
[A and D] - Movimentar
[Space Bar] - saltar
[Alt + F4] - Fechar o jogo